"""Test scaffolding: load registry, resolve ${constants}, parametrize.

The `host` fixture below is the ONE seam you swap for real infrastructure.
It currently returns a FakeHost so the slice runs end-to-end with no box.
Replace it with testinfra or a pyinfra wrapper when you're ready.
"""
import glob
import os
import re
import yaml
import pytest

HERE = os.path.dirname(__file__)
REGISTRY_DIR = os.path.join(HERE, "registry")
CONSTANTS_FILE = os.path.join(REGISTRY_DIR, "constants.yaml")

TOKEN = re.compile(r"^\$\{(\w+)\}$")


def load_constants():
    with open(CONSTANTS_FILE) as f:
        return yaml.safe_load(f) or {}


def resolve(node, consts):
    """Recursively replace whole-value ${name} tokens with the constant value.

    Anchored match means a token becomes the actual constant (list stays a
    list); it is never spliced into a larger string. Unknown names fail loud
    at load time, before any test runs.
    """
    if isinstance(node, dict):
        return {k: resolve(v, consts) for k, v in node.items()}
    if isinstance(node, list):
        return [resolve(v, consts) for v in node]
    if isinstance(node, str):
        m = TOKEN.match(node)
        if m:
            key = m.group(1)
            if key not in consts:
                raise KeyError(f"Unknown constant: ${{{key}}}")
            return consts[key]
    return node


def load_requirements():
    consts = load_constants()
    reqs = []
    for path in sorted(glob.glob(os.path.join(REGISTRY_DIR, "*.yaml"))):
        if os.path.basename(path) == "constants.yaml":
            continue  # constants are values, not requirements
        with open(path) as f:
            reqs += yaml.safe_load(f) or []
    return [resolve(r, consts) for r in reqs]


def pytest_generate_tests(metafunc):
    if "requirement" in metafunc.fixturenames:
        reqs = load_requirements()
        metafunc.parametrize(
            "requirement", reqs, ids=[r["id"] for r in reqs]
        )


# --------------------------------------------------------------------------
# Runnable stand-in for a real connection. Delete when wiring testinfra/pyinfra.
# --------------------------------------------------------------------------
class CommandResult:
    def __init__(self, stdout="", exit_status=0):
        self.stdout = stdout
        self.exit_status = exit_status


class FakeHost:
    """Canned responses so the example suite runs and mostly passes."""

    def run(self, cmd):
        if "PermitRootLogin" in cmd:
            return CommandResult("permitrootlogin no\n")
        if "PasswordAuthentication" in cmd:
            return CommandResult("passwordauthentication no\n")
        if "AllowGroups" in cmd:
            return CommandResult("allowgroups vmadmins\n")
        if "net.ipv4.ip_forward" in cmd:
            return CommandResult("0\n")
        if "rp_filter" in cmd:
            return CommandResult("1\n")
        if "getent group vmadmins" in cmd:
            return CommandResult("vmadmins:x:1001:alice,bob\n")
        return CommandResult("", 1)


@pytest.fixture
def host():
    # Swap this single return for your real backend:
    #   testinfra: return testinfra.get_host("ssh://hypervisor01")
    #   pyinfra:   return a thin wrapper exposing .run()
    return FakeHost()
