"""The entire test suite: one function, however many requirements.

A requirement is either single-check (`check` + `args`) or multi-check
(`checks:` list, AND semantics). Both are normalized to a list, then every
sub-check runs and ALL failures are collected — so a multi-check failure
still tells you exactly which sub-check broke, by requirement id.
"""
from checks import REGISTRY


def _normalize(requirement):
    if "checks" in requirement:
        return requirement["checks"]
    return [{"check": requirement["check"], "args": requirement["args"]}]


def test_requirement(requirement, host, record_property):
    record_property("requirement_id", requirement["id"])

    failures = []
    for c in _normalize(requirement):
        fn = REGISTRY[c["check"]]            # string -> function (the seam)
        passed, actual = fn(host, **c["args"])  # ** unpacks args by name
        if not passed:
            failures.append(
                f"{c['check']}({c['args']}) -> got {actual!r}"
            )

    assert not failures, (
        f"{requirement['id']} ({requirement['desc']}) failed:\n  "
        + "\n  ".join(failures)
    )
