# Importing linux populates REGISTRY via the @check decorators.
from .linux import REGISTRY  # noqa: F401
