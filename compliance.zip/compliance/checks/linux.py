"""Check primitives.

Every check function obeys the SAME contract:

    def some_check(host, **args) -> tuple[bool, Any]
        returns (passed, actual)

`host` is anything exposing `.run(cmd) -> CommandResult`, where CommandResult
has `.stdout` (str) and `.exit_status` (int). testinfra's host.run(), a thin
pyinfra wrapper, or the FakeHost in conftest all satisfy this.

Checks register themselves into REGISTRY via the @check decorator, so adding a
primitive never means editing a central dict by hand.
"""

REGISTRY = {}


def check(name):
    """Register a function under `name` so registry rows can reference it."""
    def wrap(fn):
        REGISTRY[name] = fn
        return fn
    return wrap


@check("sshd_config")
def sshd_config(host, key, expected):
    # `sshd -T` prints the effective config, lowercased keys, one per line.
    res = host.run(f"sshd -T | grep -i '^{key} '")
    actual = None
    if res.stdout.strip():
        parts = res.stdout.strip().split(None, 1)
        actual = parts[1].strip() if len(parts) > 1 else ""
    return actual == str(expected).lower(), actual


@check("sysctl")
def sysctl(host, key, expected):
    res = host.run(f"sysctl -n {key}")
    actual = res.stdout.strip()
    return actual == str(expected), actual


@check("group_members")
def group_members(host, group, expected):
    # `getent group NAME` -> name:x:gid:user1,user2
    res = host.run(f"getent group {group}")
    line = res.stdout.strip()
    if not line:
        return False, None
    members_field = line.split(":")[3] if line.count(":") >= 3 else ""
    actual = sorted(m for m in members_field.split(",") if m)
    return actual == sorted(expected), actual
