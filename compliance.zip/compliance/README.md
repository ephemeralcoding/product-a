# Compliance Test Slice

Automated IT-security compliance checks. Requirements live as YAML data; a small
library of check primitives does the host queries; one parametrized pytest drives
everything and emits junit XML where each result maps to a requirement ID.

## Layout
```
compliance/
  registry/
    constants.yaml     # reusable values, referenced as ${name}
    ssh.yaml           # requirements (single- and multi-check examples)
    kernel.yaml
  checks/
    __init__.py        # imports linux to populate REGISTRY
    linux.py           # check primitives + @check registration
  conftest.py          # load registry, resolve ${constants}, parametrize, host fixture
  test_compliance.py   # the entire test suite (one function)
  pytest.ini           # junit_family = legacy (so record_property lands in XML)
  requirements.txt
  HANDOFF_PROMPT.md    # design summary for another LLM
```

## Run
```bash
pip install -r requirements.txt
pytest -v --junitxml=report.xml
```
Ships with a `FakeHost` (canned responses) so it runs with no real machine.

## Add a requirement
Append a row to a registry file. No Python needed if an existing check fits:
```yaml
- id: SSH-003
  desc: "SSH protocol 2 only"
  check: sshd_config
  args: { key: Protocol, expected: "2" }
```

## Add a check primitive
Only when a genuinely new *kind* of check appears. In `checks/linux.py`:
```python
@check("file_mode")
def file_mode(host, path, mode):
    res = host.run(f"stat -c '%a' {path}")
    actual = res.stdout.strip()
    return actual == str(mode), actual
```
Return `(passed, actual)` — that uniform contract is what lets the one test
function drive any check.

## Wire a real host
Replace the one-line return in the `host` fixture (conftest.py):
```python
import testinfra
@pytest.fixture
def host():
    return testinfra.get_host("ssh://hypervisor01")
```
Any object with `.run(cmd) -> result(.stdout, .exit_status)` works.

## Constants
Define once in `registry/constants.yaml`, reference with `${name}` anywhere in a
requirement. A token becomes the whole value with its type intact (a list stays a
list). Unknown names fail loudly at load time.
