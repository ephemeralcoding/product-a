# Handoff Prompt — Compliance Test Framework (pytest + pyinfra/testinfra)

You are helping build an automated IT-security compliance test suite in Python.
A working vertical slice already exists with the architecture below. Preserve
these design decisions unless explicitly asked to change them; they were chosen
deliberately.

## Goal
Verify a host's security posture against a list of IT-security requirements,
producing auditor-friendly output (junit XML) where each result maps 1:1 to a
requirement ID. Target hosts: a KVM/QEMU/libvirt hypervisor platform (Rocky/RHEL
hosts, Windows guests), delivered as air-gapped one-shot customer deployments.

## Core architecture (three decoupled layers)
1. **Requirements as data.** A YAML registry. Each row is one requirement with
   a stable `id`, a human `desc`, and either:
   - a single check: `check: <name>` + `args: {...}`, or
   - multiple checks: `checks:` (a list of `{check, args}`), combined with AND.
   You add coverage by appending YAML rows, NOT by writing Python.

2. **A small check library.** Each `check` name maps to one Python function.
   Functions register themselves via an `@check("name")` decorator into a
   `REGISTRY` dict. Every check obeys ONE contract:
       def fn(host, **args) -> (passed: bool, actual)
   Many requirements collapse onto few check primitives (sshd_config, sysctl,
   group_members, file_mode, service_enabled, ...). That many-to-few ratio is
   the point.

3. **The mapping is the registry rows.** A single parametrized pytest test
   resolves `check` string -> function via REGISTRY, calls it with `**args`,
   and asserts. The pytest node id IS the requirement id (e.g.
   `test_requirement[SSH-002]`), so junit output traces straight to controls.

## The seam (most important concept)
Registry and check library never reference each other directly. They join at
runtime: the `check:` string is a key into `REGISTRY`. Contract:
- the string in `check:` must exist as a REGISTRY key (else KeyError, loud, early)
- the keys in `args:` must match the function's parameter names (else TypeError)
- every check returns `(passed, actual)` — uniform return is what lets the one
  test function drive any check unchanged.

## Multiple checks per requirement
Normalized: a single-check row is treated as a list of one. All sub-checks run;
failures are COLLECTED (not short-circuited), so a multi-check failure still
names the exact sub-check that broke. Use multi-check only when a partial pass
would be meaningless (the requirement is a genuine conjunction).

## Constants / reuse (single source of truth)
Reusable values (admin rosters, groups, log servers) live in
`registry/constants.yaml`. Requirements reference them with a whole-value token
`${name}`. Resolution happens once at load time in conftest:
- the token match is anchored (`^\$\{(\w+)\}$`), so `${admins}` becomes the
  actual value with its type intact (a list stays a list — critical for checks
  like group_members that compare lists).
- resolution recurses through dicts/lists so a token works at any depth.
- unknown constant -> KeyError at load time, before any test runs.
Do NOT use YAML anchors for this: anchors only resolve within a single file,
and constants must be referenced across multiple registry files.

## The host seam
Checks depend only on `host.run(cmd) -> result` where result has `.stdout` and
`.exit_status`. This abstracts the backend. Decision still open:
- **testinfra**: more pytest-native, read-only, lowest friction for pure
  verification. Recommended default if only verifying.
- **pyinfra**: justified if you want ONE tool to both verify and remediate.
  Its Linux facts are rich; Windows facts are thin.
- **Windows guests** will likely need a separate PowerShell-based check backend.
  Plan for two backends behind the same `(passed, actual)` contract.
The current slice ships a `FakeHost` with canned responses so it runs with no
real box; replace the one-line `host` fixture return to wire a real backend.

## Deliberately deferred (do NOT add unless asked)
- **coverage field (full/partial/none)** + manual attestation: the design
  supports distinguishing fully-automatable requirements from policy
  requirements that need human sign-off, via a `coverage:` field and
  `record_property`. The user chose to START SIMPLE WITHOUT IT. The honest
  framing for later: most "general IT security" lists are partly policy/process
  (incident response, access reviews, training) that have NO technical hook —
  forcing technical checks onto them manufactures meaningless green results.
  When ready, reintroduce `coverage` and route `none` rows to a manual
  checklist deliverable instead of running them as tests.
- **per-sub-check junit entries** (IDs like `AUD-001.a`): flatten groups into
  parametrized sub-cases only if an auditor needs each sub-check as its own
  `<testcase>`. Adds complexity to the one-row-one-result model.
- **host-specific constants**: if a constant must vary per host/environment,
  promote constants from a flat global file to a per-host fixture resolved
  against `host`. Same `${...}` syntax, different lookup source.
- **comparison operators** (`>=`, `<=`): the password-policy example assumed an
  `op` field. Current checks do exact-equality only. Add an `op` comparator to
  check functions when range checks (minlen >= 14, etc.) are needed.

## Integration target
Runs as an Azure DevOps pipeline stage producing junit XML. The user works in an
on-prem Azure DevOps Server / air-gapped context, so assume no public internet at
runtime; pin/vendor dependencies accordingly.

## Likely next steps to offer
- Wire a real `host` backend (testinfra first) and run against one box.
- Grow check primitives: file_mode, package_absent, service_enabled/masked,
  login_defs/pwquality, command_succeeds.
- Consider mapping requirements onto CIS Benchmark / DISA STIG IDs and letting
  OpenSCAP/oscap carry the bulk RHEL baseline, reserving this framework for
  platform-specific checks + unified reporting.
- Add a second registry category as a second vertical slice.

## Style
The user is a senior software engineer; prefers concise, technically precise
output and reasoning about trade-offs over boilerplate. Don't over-explain
basics; do flag design forks and their consequences.
