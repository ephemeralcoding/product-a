#!/usr/bin/env python3
"""
Read SoT files under sot/ and emit per-build config files plus a build manifest.

For each location-host pair, the generator emits:
  generated/builds/<location>__<host>/
    requirements.yml          - collection pins for ansible-galaxy
    build-vars.yml            - vars consumed by the ansible playbook during build
    <host>.pkrvars.hcl        - per-build variable file for Packer

And one global file:
  generated/build_manifest.yml    - flat list of all builds; drives the pipeline

The generator does no inheritance beyond a small, deliberate shallow merge of
defaults into each host's image and connection blocks. It does not compute
derived values, resolve dependencies, or generate playbooks.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import yaml
from jinja2 import Environment, FileSystemLoader, StrictUndefined

REPO_ROOT = Path(__file__).resolve().parent.parent
SOT_DIR = REPO_ROOT / "sot"
OUT_DIR = REPO_ROOT / "generated"
TEMPLATES_DIR = Path(__file__).resolve().parent / "templates"

VALID_OS_FAMILIES = {"linux", "windows"}


# ---------------------------------------------------------------------------
# Load
# ---------------------------------------------------------------------------

def load_sot_files() -> list[dict[str, Any]]:
    """Load every YAML file under sot/. Each file is one location."""
    files = sorted(SOT_DIR.glob("*.yml"))
    if not files:
        raise ValueError(f"No SoT files found under {SOT_DIR}")
    locations = []
    for path in files:
        with open(path) as f:
            loc = yaml.safe_load(f)
        if loc is None:
            raise ValueError(f"{path.name}: file is empty")
        validate_location(loc, path)
        locations.append(loc)
    return locations


# ---------------------------------------------------------------------------
# Validate
# ---------------------------------------------------------------------------

def validate_location(loc: dict[str, Any], path: Path) -> None:
    """Fail loud on malformed SoT before any rendering."""
    where = path.name

    if not isinstance(loc, dict):
        raise ValueError(f"{where}: top level must be a mapping")

    required_top = ("location", "hosts")
    for key in required_top:
        if key not in loc:
            raise ValueError(f"{where}: missing required key '{key}'")

    if "-" in loc["location"]:
        # Hyphens are allowed in location names since they don't become
        # Ansible group names directly; we use underscores in build_ids.
        pass

    hosts = loc["hosts"]
    if not isinstance(hosts, dict) or not hosts:
        raise ValueError(f"{where}: 'hosts' must be a non-empty mapping")

    for host_name, host in hosts.items():
        prefix = f"{where}: hosts.{host_name}"

        if "-" in host_name:
            raise ValueError(
                f"{prefix}: host name contains a hyphen; use underscores "
                f"(Ansible group naming rule)"
            )

        for section in ("image", "instance"):
            if section not in host:
                raise ValueError(f"{prefix}: missing required section '{section}'")
            if not isinstance(host[section], dict):
                raise ValueError(f"{prefix}.{section}: must be a mapping")

        img = host["image"]
        for required in ("base_os", "os_family", "collections", "roles"):
            if required not in img:
                raise ValueError(f"{prefix}.image: missing required key '{required}'")

        if img["os_family"] not in VALID_OS_FAMILIES:
            raise ValueError(
                f"{prefix}.image.os_family: must be one of {sorted(VALID_OS_FAMILIES)}, "
                f"got {img['os_family']!r}"
            )

        if not isinstance(img["collections"], dict) or not img["collections"]:
            raise ValueError(f"{prefix}.image.collections: must be a non-empty mapping")

        if not isinstance(img["roles"], list) or not img["roles"]:
            raise ValueError(f"{prefix}.image.roles: must be a non-empty list")

        inst = host["instance"]
        for required in ("hostname", "ip"):
            if required not in inst:
                raise ValueError(f"{prefix}.instance: missing required key '{required}'")


# ---------------------------------------------------------------------------
# Resolve (shallow merge of defaults into host image + connection)
# ---------------------------------------------------------------------------

def resolve_image(defaults: dict[str, Any], host_image: dict[str, Any]) -> dict[str, Any]:
    """
    Shallow-merge image defaults into the host's image block, then layer the
    OS-family connection defaults under image['connection'], with host
    connection overrides on top.

    Rules:
      - Host scalar keys win over defaults.
      - 'collections' and 'roles' are NEVER taken from defaults (would mask
        per-host requirements). They must be declared per host.
      - 'connection' merge is shallow within the OS-family block.
    """
    image_defaults = defaults.get("image", {})

    # Start from defaults (scalars only — collections/roles aren't defaulted),
    # then overlay host image. Host wins for any key it sets.
    merged: dict[str, Any] = {
        k: v for k, v in image_defaults.items()
        if k not in ("collections", "roles", "connection")
    }
    merged.update(host_image)

    # Resolve connection: defaults.connection.<os_family> overlaid with
    # whatever the host put in image.connection (if anything).
    os_family = host_image["os_family"]
    conn_defaults_all = defaults.get("connection", {})
    conn_for_family = conn_defaults_all.get(os_family, {})
    conn_host = host_image.get("connection", {})

    merged_conn = {**conn_for_family, **conn_host}
    if merged_conn:
        merged["connection"] = merged_conn

    return merged


# ---------------------------------------------------------------------------
# Render
# ---------------------------------------------------------------------------

def make_env() -> Environment:
    return Environment(
        loader=FileSystemLoader(TEMPLATES_DIR),
        undefined=StrictUndefined,
        trim_blocks=True,
        lstrip_blocks=True,
        keep_trailing_newline=True,
    )


def render(env: Environment, template_name: str, ctx: dict[str, Any], out_path: Path) -> None:
    template = env.get_template(template_name)
    rendered = template.render(**ctx)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(rendered)
    print(f"  wrote {out_path.relative_to(REPO_ROOT)}")


def build_id(location: str, host_name: str) -> str:
    return f"{location}__{host_name}"


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    if OUT_DIR.exists():
        # Don't auto-delete; just ensure it exists. Stale files can mislead.
        # Operators can `rm -rf generated/` to fully reset.
        pass
    OUT_DIR.mkdir(exist_ok=True)

    env = make_env()
    locations = load_sot_files()

    all_builds: list[dict[str, Any]] = []

    for loc in locations:
        location_name = loc["location"]
        defaults = loc.get("defaults", {})

        print(f"Location: {location_name}")
        for host_name, host in loc["hosts"].items():
            bid = build_id(location_name, host_name)
            build_dir = OUT_DIR / "builds" / bid

            resolved_image = resolve_image(defaults, host["image"])
            instance = host["instance"]

            ctx = {
                "build_id": bid,
                "location": location_name,
                "host_name": host_name,
                "image": resolved_image,
                "instance": instance,
            }

            render(env, "requirements.yml.j2", ctx,
                   build_dir / "requirements.yml")
            render(env, "build-vars.yml.j2", ctx,
                   build_dir / "build-vars.yml")
            render(env, "pkrvars.hcl.j2", ctx,
                   build_dir / f"{host_name}.pkrvars.hcl")

            all_builds.append({
                "id": bid,
                "location": location_name,
                "host": host_name,
                "base_os": resolved_image["base_os"],
                "os_family": resolved_image["os_family"],
                "disk_size_gb": resolved_image["disk_size_gb"],
                "memory_mb": resolved_image["memory_mb"],
                "cpus": resolved_image["cpus"],
                "pkrvars_path": str(
                    (build_dir / f"{host_name}.pkrvars.hcl").relative_to(REPO_ROOT)
                ),
            })

    render(env, "build_manifest.yml.j2", {"builds": all_builds},
           OUT_DIR / "build_manifest.yml")

    print(f"\nGenerated {len(all_builds)} build(s) across {len(locations)} location(s).")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)
