#!/usr/bin/env python3
"""
Read SoT files under sot/ and emit per-build config files plus a build manifest.

For each location-host pair:
  generated/builds/<location>__<host>/
    requirements.yml          - collection pins for ansible-galaxy
    build-vars.yml            - vars consumed by the ansible playbook during build
    <host>.pkrvars.hcl        - per-build variable file for Packer

And one global file:
  generated/build_manifest.yml    - flat list of all builds; drives the Makefile

The generator does one shallow merge: defaults.image + defaults.winrm overlaid
into the host. Host wins. No deep merging, no derived values, no playbook
generation.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import yaml
from jinja2 import Environment, FileSystemLoader, StrictUndefined

REPO_ROOT = Path(__file__).resolve().parent.parent
SOT_DIR = REPO_ROOT / "sot"
OUT_DIR = REPO_ROOT / "generated"
TEMPLATES_DIR = Path(__file__).resolve().parent / "templates"


def load_sot_files() -> list[dict[str, Any]]:
    files = sorted(SOT_DIR.glob("*.yml"))
    if not files:
        raise ValueError(f"No SoT files found under {SOT_DIR}")
    locations = []
    for path in files:
        with open(path) as f:
            loc = yaml.safe_load(f)
        if not isinstance(loc, dict):
            raise ValueError(f"{path.name}: top level must be a mapping")
        validate(loc, path.name)
        locations.append(loc)
    return locations


def validate(loc: dict[str, Any], where: str) -> None:
    """Two checks: required keys, and the hyphen-in-host-name foot-gun."""
    for key in ("location", "hosts"):
        if key not in loc:
            raise ValueError(f"{where}: missing required key '{key}'")
    if not isinstance(loc["hosts"], dict) or not loc["hosts"]:
        raise ValueError(f"{where}: 'hosts' must be a non-empty mapping")

    for host_name, host in loc["hosts"].items():
        prefix = f"{where}: hosts.{host_name}"
        if "-" in host_name:
            raise ValueError(
                f"{prefix}: host name contains a hyphen; use underscores"
            )
        for section in ("image", "instance"):
            if section not in host:
                raise ValueError(f"{prefix}: missing required section '{section}'")
        for required in ("base_os", "collections", "roles"):
            if required not in host["image"]:
                raise ValueError(f"{prefix}.image: missing required key '{required}'")


def resolve_image(defaults: dict[str, Any], host_image: dict[str, Any]) -> dict[str, Any]:
    """Shallow merge: image defaults overlaid by host image. Host wins."""
    image_defaults = {
        k: v for k, v in defaults.get("image", {}).items()
        if k not in ("collections", "roles")  # never default these
    }
    return {**image_defaults, **host_image}


def make_env() -> Environment:
    return Environment(
        loader=FileSystemLoader(TEMPLATES_DIR),
        undefined=StrictUndefined,
        trim_blocks=True,
        lstrip_blocks=True,
        keep_trailing_newline=True,
    )


def render(env: Environment, template: str, ctx: dict[str, Any], out: Path) -> None:
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(env.get_template(template).render(**ctx))
    print(f"  wrote {out.relative_to(REPO_ROOT)}")


def main() -> None:
    OUT_DIR.mkdir(exist_ok=True)
    env = make_env()
    locations = load_sot_files()
    builds: list[dict[str, Any]] = []

    for loc in locations:
        location = loc["location"]
        defaults = loc.get("defaults", {})
        winrm = defaults.get("winrm", {})

        print(f"Location: {location}")
        for host_name, host in loc["hosts"].items():
            build_id = f"{location}__{host_name}"
            build_dir = OUT_DIR / "builds" / build_id
            image = resolve_image(defaults, host["image"])

            ctx = {
                "build_id": build_id,
                "location": location,
                "host_name": host_name,
                "image": image,
                "instance": host["instance"],
                "winrm": winrm,
            }

            render(env, "requirements.yml.j2", ctx, build_dir / "requirements.yml")
            render(env, "build-vars.yml.j2", ctx, build_dir / "build-vars.yml")
            render(env, "pkrvars.hcl.j2", ctx, build_dir / f"{host_name}.pkrvars.hcl")

            builds.append({
                "id": build_id,
                "location": location,
                "host": host_name,
                "base_os": image["base_os"],
            })

    render(env, "build_manifest.yml.j2", {"builds": builds},
           OUT_DIR / "build_manifest.yml")
    print(f"\nGenerated {len(builds)} build(s) across {len(locations)} location(s).")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)
