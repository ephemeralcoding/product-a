# hypervisor-fleet (POC)

SoT-driven Windows image building for an air-gapped hypervisor platform.

## What this is

1. A YAML **Source of Truth** describes a location's hosts and what to build.
2. A small Python **generator** turns the SoT into per-build Ansible + Packer inputs.
3. A **Makefile** orchestrates: generate, then run Packer for each build.

Local and CI use the same Makefile. CI is just "run `make build-all` with the
right env vars set."

## Layout

```
hypervisor-fleet/
  Makefile                      Orchestrator. The connective tissue.
  sot/
    acme-hq.yml                 One file per location.
  generator/
    generate.py                 Reads SoT, renders templates.
    templates/                  Jinja2 templates for outputs.
    requirements.txt            PyYAML + Jinja2.
  packer/
    variables.pkr.hcl           Variable declarations (auto-loaded).
    sources.pkr.hcl             qemu source for Windows.
    build.pkr.hcl               Build block with ansible + provenance + upload.
    playbook.yml                Generic playbook applied to every image.
    ansible.cfg                 Galaxy auth.
    http/                       autounattend.xml lives here.
  generated/                    Generator output. Treat as ephemeral.
```

## Core model

Every parameter is one of two kinds:

- **Type A (build-time)** -- baked into the qcow. Lives under `image:`.
- **Type B (instance identity)** -- applied post-boot. Lives under `instance:`.

The qcow is generic. Identity is applied later (Stage 2 / Terraform / cloud-init).

## SoT structure

```yaml
location: acme-hq

defaults:
  image:                       # shallow-merged into each host.image
    disk_size_gb: 80
    memory_mb: 4096
    cpus: 2
  winrm:                       # passed through to Packer for the WinRM connection
    username: Administrator
    timeout: "2h"
    password_ref: builder_winrm_password    # reference; real password in env

hosts:
  controller:
    image:
      base_os: windows-server-2022
      collections: { ... }
      roles:       [ ... ]
      vars:        { ... }
    instance:
      hostname: ctrl01
      ip: 10.20.1.11
      vlan: 42
```

Rules:
- `defaults.image` shallow-merges scalars only. `collections` and `roles`
  are never defaulted -- they vary by host and must be declared.
- Credentials are references (`password_ref`), never values.

## Running locally

```bash
# One-time
make venv

# Required env vars for builds
export ARTIFACTORY_TOKEN="..."
export PACKER_WINRM_PASSWORD="..."

# Generate per-build config from SoT
make generate

# See what's available
make list-builds

# Build one image
make build-one BUILD_ID=acme-hq__controller

# Build everything in the manifest, sequentially
make build-all
```

For the first run, comment out the `post-processor "shell-local"` block in
`packer/build.pkr.hcl` so the qcow stays local. Verify it boots and the
provenance file at `C:\hypervisor\image-manifest.yml` is present, then
re-enable the upload.

## Running in CI

The pipeline runs `make build-all` (or `make build-one` for a manual single
build) with `ARTIFACTORY_TOKEN` and `PACKER_WINRM_PASSWORD` injected from the
secret store. Identical commands to local. No CI-specific build logic.

## Adding to the fleet

- New host at an existing location: add an entry under `hosts:` in the SoT.
  Run `make generate && make build-one BUILD_ID=<location>__<new-host>`.
- New location: create `sot/<new-location>.yml`. Same flow.

## What's not here yet

- Terraform configs from the `instance:` section (Stage 2 deploy).
- An ADO pipeline wrapping the Makefile.
- A working autounattend.xml for the Windows install.
- Real role implementations in the referenced collections.
