# hypervisor-fleet (POC)

Source-of-Truth-driven image building for an air-gapped hypervisor platform.

## What this is

A small, working proof-of-concept that:

1. Reads a YAML **Source of Truth** describing a location's hosts and the
   images they need.
2. Generates per-build Ansible + Packer inputs from the SoT.
3. Drives Packer to build qcow2 images, provisioned by Ansible from
   versioned collections in Artifactory.

This is the build half (Stage 1). Stage 2 (Terraform deploy) is intentionally
out of scope for now; the SoT already carries the data Terraform will need.

## Layout

```
hypervisor-fleet/
  sot/                          One YAML file per location (air-gap unit).
    acme-hq.yml
  generator/
    generate.py                 Reads SoT, renders templates, emits build/.
    templates/                  Jinja2 templates for the outputs.
  packer/
    variables.pkr.hcl           Variable declarations (auto-loaded).
    sources.pkr.hcl             Linux + Windows source blocks.
    build.pkr.hcl               Build block with ansible + provenance.
    playbook.yml                Static generic playbook for image builds.
    ansible.cfg                 ansible-galaxy auth + collections config.
    http/{linux,windows}/       Preseed / autounattend files.
  generated/                    Generator output. Treat as ephemeral.
    builds/<location>__<host>/
      requirements.yml
      build-vars.yml
      <host>.pkrvars.hcl
    build_manifest.yml          Flat list of all builds; drives the pipeline.
```

## Core model: A vs B

Every parameter in the SoT is one of two kinds:

- **Type A (build-time)** -- baked into the qcow. Lives under `image:`.
  Examples: base OS, disk size, roles, collection versions.
- **Type B (instance identity)** -- applied to a VM after boot. Lives under
  `instance:`. Examples: hostname, IP, VLAN.

The generator routes each section to its correct downstream tool:
`image:` -> Packer/Ansible, `instance:` -> Terraform (future stage).
The qcow is **generic**: no hostname, no IP, no VLAN. Identity is applied
post-boot at deploy time.

## SoT structure

Each `sot/<location>.yml` is self-contained:

```yaml
location: acme-hq

defaults:                      # Shallow-merged into each host's image block
  image:
    disk_size_gb: 40
    memory_mb: 2048
    cpus: 2
  connection:
    linux:
      type: ssh
      username: packer
      ssh_key_ref: builder_ssh_key
    windows:
      type: winrm
      username: Administrator
      password_ref: builder_winrm_password

hosts:
  controller:
    image:
      base_os: ubuntu-24.04
      os_family: linux
      collections: { ... }
      roles:       [ ... ]
      vars:        { ... }
    instance:
      hostname: ctrl01
      ip: 10.20.1.11
      vlan: 42
```

- `defaults` is optional and only does a *shallow* merge of scalar image
  keys plus the OS-family-specific connection block.
- `collections` and `roles` are NEVER taken from defaults -- they must be
  declared per host (they vary by image type).
- Credentials are *references* (`ssh_key_ref`, `password_ref`), not values.
  The actual material is resolved at runtime from env vars / secret store.

## Running the generator

```bash
python3 -m venv .venv
.venv/bin/pip install pyyaml jinja2
.venv/bin/python generator/generate.py
```

Expected output:

```
Location: acme-hq
  wrote generated/builds/acme-hq__controller/requirements.yml
  wrote generated/builds/acme-hq__controller/build-vars.yml
  wrote generated/builds/acme-hq__controller/controller.pkrvars.hcl
  wrote generated/builds/acme-hq__compute/...
  wrote generated/builds/acme-hq__windows_mgmt/...
  wrote generated/build_manifest.yml

Generated 3 build(s) across 1 location(s).
```

## Running one Packer build

```bash
# Required env vars
export ARTIFACTORY_TOKEN="..."
export PACKER_SSH_PRIVATE_KEY="$(cat ~/.ssh/builder_ssh_key)"
export PACKER_WINRM_PASSWORD="..."     # only needed for Windows builds

cd packer
packer init .

# Pick one build from the manifest:
packer build \
  -var-file=../generated/builds/acme-hq__controller/controller.pkrvars.hcl \
  .
```

For the very first run, comment out the `post-processor "shell-local"` block
in `build.pkr.hcl` to leave the qcow locally. Boot it, verify
`/etc/hypervisor/image-manifest.yml`, then re-enable the upload.

## Adding a new build

- New host at an existing location: add an entry under `hosts:` in the
  location's SoT file. Re-run the generator.
- New location: create `sot/<new-location>.yml`. Re-run the generator.

The generator handles both with the same code path. No template edits, no
pipeline changes.

## What's *not* here yet

- Terraform configs from the `instance:` section (Stage 2 deploy).
- A CI pipeline driving the build manifest (consume `build_manifest.yml`,
  fan out one Packer run per entry).
- ISO mirror in Artifactory + a working autounattend.xml for Windows.
- Real role implementations in the referenced collections.

These are the next layers, added one at a time against this foundation.
