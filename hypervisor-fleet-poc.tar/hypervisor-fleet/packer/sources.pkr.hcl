# Single qemu source for Windows builds. No OS branching.

source "qemu" "windows" {
  vm_name          = "${var.build_id}.qcow2"
  output_directory = "${var.qcow_output_dir}/${var.build_id}"
  disk_size        = "${var.disk_size_gb}G"
  format           = "qcow2"
  accelerator      = "kvm"
  memory           = var.memory_mb
  cpus             = var.cpus
  headless         = true

  iso_url      = "${var.artifactory_url}/artifactory/iso/${var.base_os}.iso"
  iso_checksum = "file:${var.artifactory_url}/artifactory/iso/${var.base_os}.iso.sha256"

  http_directory = "http"

  communicator   = "winrm"
  winrm_username = var.winrm_username
  winrm_password = local.resolved_winrm_password
  winrm_timeout  = var.winrm_timeout
  winrm_insecure = true
  winrm_use_ssl  = false

  shutdown_command = "shutdown /s /t 10 /f /d p:4:1 /c \"Packer Shutdown\""

  # Windows-on-QEMU needs an autounattend.xml answer file. Place it under
  # http/ and adjust paths as needed.
  cd_files = [
    "http/autounattend.xml",
  ]
  qemuargs = [
    ["-cpu", "host"],
    ["-device", "virtio-net,netdev=user.0"],
    # ["-drive", "file=/path/to/virtio-win.iso,media=cdrom,index=3"],
  ]
}
