# Source blocks for Linux and Windows image builds.
# The build block at packer/build.pkr.hcl selects one via:
#   sources = ["source.qemu.${var.os_family}"]

source "qemu" "linux" {
  vm_name          = "${var.build_id}.qcow2"
  output_directory = "${var.qcow_output_dir}/${var.build_id}"
  disk_size        = "${var.disk_size_gb}G"
  format           = "qcow2"
  accelerator      = "kvm"
  memory           = var.memory_mb
  cpus             = var.cpus
  headless         = true

  iso_url      = "${var.artifactory_url}/artifactory/iso/${var.base_os}.iso"
  iso_checksum = "file:${var.artifactory_url}/artifactory/iso/${var.base_os}.iso.sha256"

  http_directory = "http/linux"

  communicator        = "ssh"
  ssh_username        = var.ssh_username
  ssh_port            = var.ssh_port
  ssh_timeout         = var.ssh_timeout
  ssh_private_key_file = ""  # populated by ansible_env_vars below if using key
  ssh_password        = ""   # set this if your linux ISO uses password auth at first boot

  shutdown_command = "sudo shutdown -P now"

  # Adjust qemuargs as needed for your environment (network, virtio, etc.)
  qemuargs = [
    ["-cpu", "host"],
  ]
}

source "qemu" "windows" {
  vm_name          = "${var.build_id}.qcow2"
  output_directory = "${var.qcow_output_dir}/${var.build_id}"
  disk_size        = "${var.disk_size_gb}G"
  format           = "qcow2"
  accelerator      = "kvm"
  memory           = var.memory_mb
  cpus             = var.cpus
  headless         = true

  iso_url      = "${var.artifactory_url}/artifactory/iso/${var.base_os}.iso"
  iso_checksum = "file:${var.artifactory_url}/artifactory/iso/${var.base_os}.iso.sha256"

  http_directory = "http/windows"

  communicator   = "winrm"
  winrm_username = var.winrm_username
  winrm_password = local.resolved_winrm_password
  winrm_port     = var.winrm_port
  winrm_timeout  = var.winrm_timeout
  winrm_use_ssl  = var.winrm_use_ssl
  winrm_insecure = true

  shutdown_command = "shutdown /s /t 10 /f /d p:4:1 /c \"Packer Shutdown\""

  # Windows-on-QEMU typically needs an autounattend answer file and virtio drivers.
  # Place autounattend.xml under http/windows/ and adjust paths as needed.
  cd_files = [
    "http/windows/autounattend.xml",
  ]
  qemuargs = [
    ["-cpu", "host"],
    ["-device", "virtio-net,netdev=user.0"],
    # ["-drive", "file=/path/to/virtio-win.iso,media=cdrom,index=3"],
  ]
}
