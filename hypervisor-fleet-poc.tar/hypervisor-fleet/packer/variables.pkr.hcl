# Packer variable declarations.
# Auto-loaded by Packer alongside all other *.pkr.hcl in this directory.
# Per-build values come from the generator's pkrvars file via -var-file.
# Secrets come from env vars - never from a vars file, never committed.

# --- Per-build identity (from generator) ----------------------------------

variable "build_id" {
  type = string
}

variable "location" {
  type = string
}

variable "host_name" {
  type = string
}

variable "base_os" {
  type = string
}

variable "disk_size_gb" {
  type    = number
  default = 80
}

variable "memory_mb" {
  type    = number
  default = 4096
}

variable "cpus" {
  type    = number
  default = 2
}

# --- Ansible inputs (from generator) --------------------------------------

variable "ansible_playbook" {
  type    = string
  default = "./playbook.yml"
}

variable "ansible_vars_file" {
  type = string
}

variable "ansible_requirements_file" {
  type = string
}

# --- Connection (Windows / WinRM) -----------------------------------------

variable "winrm_username" {
  type    = string
  default = "Administrator"
}

variable "winrm_timeout" {
  type    = string
  default = "2h"
}

variable "winrm_password_ref" {
  type        = string
  default     = ""
  description = "Reference name only -- the real password comes from env."
}

# --- Secrets (resolved from env vars at runtime) --------------------------

variable "artifactory_token" {
  type        = string
  sensitive   = true
  default     = ""
  description = "From ARTIFACTORY_TOKEN env var."
}

variable "winrm_password" {
  type        = string
  sensitive   = true
  default     = ""
  description = "From PACKER_WINRM_PASSWORD env var."
}

# --- Infrastructure constants ---------------------------------------------

variable "artifactory_url" {
  type    = string
  default = "https://artifactory.mycompany.local"
}

variable "qcow_output_dir" {
  type    = string
  default = "output"
}

# --- Locals: resolve secrets from env -------------------------------------

locals {
  resolved_artifactory_token = coalesce(var.artifactory_token, env("ARTIFACTORY_TOKEN"))
  resolved_winrm_password    = coalesce(var.winrm_password, env("PACKER_WINRM_PASSWORD"))
}
