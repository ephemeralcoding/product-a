# Packer variable declarations.
# Auto-loaded by Packer alongside all other *.pkr.hcl files in this directory.
# Per-build values come from `-var-file=../generated/builds/<id>/<host>.pkrvars.hcl`.
# Secrets come from env vars (never from a vars file, never committed).

# --- Build identity (per-build, supplied by generator) ---------------------

variable "build_id" {
  type        = string
  description = "Identifier from the build manifest (e.g. acme-hq__controller)"
}

variable "location" {
  type        = string
  description = "Location name (e.g. acme-hq)"
}

variable "host_name" {
  type        = string
  description = "Host group name within the location (e.g. controller, compute)"
}

# --- Image sizing & OS (per-build) -----------------------------------------

variable "base_os" {
  type        = string
  description = "Base OS identifier (e.g. ubuntu-24.04, windows-server-2022)"
}

variable "os_family" {
  type        = string
  description = "linux or windows -- selects which source block to use"

  validation {
    condition     = contains(["linux", "windows"], var.os_family)
    error_message = "os_family must be 'linux' or 'windows'."
  }
}

variable "disk_size_gb" {
  type    = number
  default = 40
}

variable "memory_mb" {
  type    = number
  default = 2048
}

variable "cpus" {
  type    = number
  default = 2
}

# --- Ansible inputs (per-build) --------------------------------------------

variable "ansible_playbook" {
  type        = string
  description = "Path to the generic image-build playbook"
  default     = "./playbook.yml"
}

variable "ansible_vars_file" {
  type        = string
  description = "Per-build vars file emitted by the generator"
}

variable "ansible_requirements_file" {
  type        = string
  description = "Per-build collection requirements emitted by the generator"
}

# --- Connection: Linux/SSH (set when os_family == 'linux') -----------------

variable "ssh_username" {
  type    = string
  default = "packer"
}

variable "ssh_port" {
  type    = number
  default = 22
}

variable "ssh_timeout" {
  type    = string
  default = "30m"
}

variable "ssh_key_ref" {
  type        = string
  default     = ""
  description = "Logical reference name for the SSH key. The actual key is loaded from the secret store via this name."
}

# --- Connection: Windows/WinRM (set when os_family == 'windows') ------------

variable "winrm_username" {
  type    = string
  default = "Administrator"
}

variable "winrm_port" {
  type    = number
  default = 5985
}

variable "winrm_timeout" {
  type    = string
  default = "2h"
}

variable "winrm_use_ssl" {
  type    = bool
  default = false
}

variable "winrm_password_ref" {
  type        = string
  default     = ""
  description = "Logical reference name for the WinRM password. Resolved from env at runtime."
}

# --- Secrets (from environment, never from vars files) ---------------------

variable "artifactory_token" {
  type        = string
  sensitive   = true
  default     = ""
  description = "Read from ARTIFACTORY_TOKEN env var by default."
}

variable "ssh_private_key" {
  type        = string
  sensitive   = true
  default     = ""
  description = "SSH private key material for Linux builds. Read from PACKER_SSH_PRIVATE_KEY env var."
}

variable "winrm_password" {
  type        = string
  sensitive   = true
  default     = ""
  description = "WinRM password for Windows builds. Read from PACKER_WINRM_PASSWORD env var."
}

# --- Infrastructure constants (rarely changed) -----------------------------

variable "artifactory_url" {
  type    = string
  default = "https://artifactory.mycompany.local"
}

variable "qcow_output_dir" {
  type    = string
  default = "output"
}

# --- Locals: secret resolution from env vars -------------------------------

locals {
  resolved_artifactory_token = coalesce(var.artifactory_token, env("ARTIFACTORY_TOKEN"))
  resolved_ssh_private_key   = coalesce(var.ssh_private_key, env("PACKER_SSH_PRIVATE_KEY"))
  resolved_winrm_password    = coalesce(var.winrm_password, env("PACKER_WINRM_PASSWORD"))
}
