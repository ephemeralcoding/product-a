# Place your Windows answer files here.
# Required: autounattend.xml (referenced by sources.pkr.hcl as cd_files)
# Optional: any post-install scripts the autounattend invokes
