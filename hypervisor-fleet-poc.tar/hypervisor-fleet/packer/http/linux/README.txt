# Place your Linux preseed/cloud-init files here.
# Examples: ubuntu cloud-init user-data, debian preseed.cfg
# Referenced by sources.pkr.hcl via http_directory = "http/linux"
