# Place autounattend.xml here (referenced by sources.pkr.hcl as cd_files).
# Also place any post-install scripts the autounattend invokes.
