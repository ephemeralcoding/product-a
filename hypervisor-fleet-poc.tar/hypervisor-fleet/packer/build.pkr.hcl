# Build block.
# Selects the right source by os_family. One playbook, one provisioner block.

packer {
  required_plugins {
    qemu = {
      version = ">= 1.0.0"
      source  = "github.com/hashicorp/qemu"
    }
    ansible = {
      version = ">= 1.1.0"
      source  = "github.com/hashicorp/ansible"
    }
  }
}

build {
  name = "image-build"

  sources = [
    "source.qemu.${var.os_family}",
  ]

  # Run the generic ansible playbook against the building VM.
  # Collections are installed inside the provisioner via galaxy_file.
  provisioner "ansible" {
    playbook_file = var.ansible_playbook
    galaxy_file   = var.ansible_requirements_file

    extra_arguments = [
      "-e", "@${var.ansible_vars_file}",
    ]

    ansible_env_vars = [
      "ARTIFACTORY_TOKEN=${local.resolved_artifactory_token}",
      "ANSIBLE_HOST_KEY_CHECKING=False",
      "ANSIBLE_CONFIG=${path.root}/ansible.cfg",
    ]

    # Use WinRM connection when building Windows
    use_proxy = false
  }

  # Provenance manifest written into the image. Survives in the qcow as
  # /etc/hypervisor/image-manifest.yml so any consumer can identify it.
  # Skipped for Windows -- write equivalent via PowerShell if needed.
  provisioner "shell" {
    only = ["qemu.linux"]
    inline = [
      "sudo mkdir -p /etc/hypervisor",
      "echo 'build_id: ${var.build_id}' | sudo tee /etc/hypervisor/image-manifest.yml",
      "echo 'location: ${var.location}' | sudo tee -a /etc/hypervisor/image-manifest.yml",
      "echo 'host: ${var.host_name}' | sudo tee -a /etc/hypervisor/image-manifest.yml",
      "echo 'base_os: ${var.base_os}' | sudo tee -a /etc/hypervisor/image-manifest.yml",
      "echo 'os_family: ${var.os_family}' | sudo tee -a /etc/hypervisor/image-manifest.yml",
      "echo \"built: $(date -u +%Y-%m-%dT%H:%M:%SZ)\" | sudo tee -a /etc/hypervisor/image-manifest.yml",
    ]
  }

  # Upload the resulting qcow to Artifactory.
  # Disable this block during initial testing -- inspect the local qcow first,
  # then re-enable once the build is known good.
  post-processor "shell-local" {
    inline = [
      <<-EOT
        set -e
        QCOW="${var.qcow_output_dir}/${var.build_id}/${var.build_id}.qcow2"
        URL="${var.artifactory_url}/artifactory/qcows-local/${var.location}/${var.host_name}/${var.build_id}.qcow2"
        echo "Uploading $QCOW -> $URL"
        curl -sfS \
          -H "Authorization: Bearer ${local.resolved_artifactory_token}" \
          -T "$QCOW" \
          "$URL"
        echo "Upload complete."
      EOT
    ]
  }
}
