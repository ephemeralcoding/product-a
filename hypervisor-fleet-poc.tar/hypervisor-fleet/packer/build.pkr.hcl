packer {
  required_plugins {
    qemu = {
      version = ">= 1.0.0"
      source  = "github.com/hashicorp/qemu"
    }
    ansible = {
      version = ">= 1.1.0"
      source  = "github.com/hashicorp/ansible"
    }
  }
}

build {
  name    = "image-build"
  sources = ["source.qemu.windows"]

  # Run the generic ansible playbook against the building VM via WinRM.
  provisioner "ansible" {
    playbook_file = var.ansible_playbook
    galaxy_file   = var.ansible_requirements_file
    use_proxy     = false

    extra_arguments = [
      "-e", "@${var.ansible_vars_file}",
      "-e", "ansible_connection=winrm",
      "-e", "ansible_winrm_transport=basic",
      "-e", "ansible_winrm_server_cert_validation=ignore",
    ]

    ansible_env_vars = [
      "ARTIFACTORY_TOKEN=${local.resolved_artifactory_token}",
      "ANSIBLE_HOST_KEY_CHECKING=False",
      "ANSIBLE_CONFIG=${path.root}/ansible.cfg",
    ]
  }

  # Provenance manifest written into the image.
  provisioner "powershell" {
    inline = [
      "New-Item -ItemType Directory -Force -Path C:\\hypervisor | Out-Null",
      "@\"",
      "build_id: ${var.build_id}",
      "location: ${var.location}",
      "host: ${var.host_name}",
      "base_os: ${var.base_os}",
      "built: $((Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ'))",
      "\"@ | Set-Content -Path C:\\hypervisor\\image-manifest.yml -Encoding UTF8",
    ]
  }

  # Upload the resulting qcow to Artifactory.
  # During initial testing, comment this out so the qcow stays local.
  post-processor "shell-local" {
    inline = [
      <<-EOT
        set -e
        QCOW="${var.qcow_output_dir}/${var.build_id}/${var.build_id}.qcow2"
        URL="${var.artifactory_url}/artifactory/qcows-local/${var.location}/${var.host_name}/${var.build_id}.qcow2"
        echo "Uploading $QCOW -> $URL"
        curl -sfS \
          -H "Authorization: Bearer ${local.resolved_artifactory_token}" \
          -T "$QCOW" \
          "$URL"
        echo "Upload complete."
      EOT
    ]
  }
}
